package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJmsProj03SubscriberApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJmsProj03SubscriberApplication.class, args);
	}

}
