package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJmsProj03SubscriberApplicationTests {

	@Test
	void contextLoads() {
	}

}
