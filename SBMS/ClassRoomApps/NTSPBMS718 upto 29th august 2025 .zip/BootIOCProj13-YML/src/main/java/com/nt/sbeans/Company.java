//Company.java
package com.nt.sbeans;

import lombok.Data;

@Data
public class Company {
   private int cid;
   private  String name;
   private  String addrs;
   private  Integer size;
}
