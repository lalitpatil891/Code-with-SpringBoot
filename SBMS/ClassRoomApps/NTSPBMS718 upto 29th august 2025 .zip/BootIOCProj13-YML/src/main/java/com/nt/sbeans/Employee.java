//Employee.java
package com.nt.sbeans;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("emp")
@ConfigurationProperties(prefix = "emp.info")
@Data
public class Employee {
	private  Integer eid;
	private String  ename;
	private  String  addrs;
	private   Float  salary;
	private   String[]  favColors;
	private   List<String> friends;
	private  Set<Long>  phones;
	private  Map<String,Object> idDetails;
	private  Company  company;
	

}
