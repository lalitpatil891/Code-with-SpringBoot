package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootCoreProj13YmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootCoreProj13YmlApplication.class, args);
	}

}
