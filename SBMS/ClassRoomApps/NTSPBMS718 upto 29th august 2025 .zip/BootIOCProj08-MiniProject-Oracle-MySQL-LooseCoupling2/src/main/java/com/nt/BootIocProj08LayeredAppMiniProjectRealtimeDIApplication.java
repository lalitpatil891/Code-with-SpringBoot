package com.nt;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.nt.controller.PayrollOperationsController;
import com.nt.model.Employee;


@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class,JdbcTemplateAutoConfiguration.class,DataSourceTransactionManagerAutoConfiguration.class})
public class BootIocProj08LayeredAppMiniProjectRealtimeDIApplication {
	@Autowired
	private  Environment env;
	
	@Bean(name="c3P0Ds")
	public  ComboPooledDataSource  createC3P0Ds() throws Exception{
		ComboPooledDataSource  c3P0Ds=new ComboPooledDataSource();
		c3P0Ds.setDriverClass(env.getProperty("spring.datasource.driver-class-name"));
		c3P0Ds.setJdbcUrl(env.getProperty("spring.datasource.url"));
		c3P0Ds.setUser(env.getProperty("spring.datasource.username"));
		c3P0Ds.setPassword(env.getProperty("spring.datasource.password"));
		return c3P0Ds;
	}

  
	public static void main(String[] args) {
		System.out.println("BootIocProj05LayeredAppMiniProjectRealtimeDIApplication.main() (start)");
		//get IOC container
		try(ConfigurableApplicationContext ctx=
				 SpringApplication.run(BootIocProj08LayeredAppMiniProjectRealtimeDIApplication.class, args);
				Scanner sc=new Scanner(System.in);){
			System.out.println("Spring bean count ::"+ctx.getBeanDefinitionCount());
			  //get  Controller class obj ref
			PayrollOperationsController  controller=ctx.getBean("controller",PayrollOperationsController.class);
		
			   //==================  gather inputs  for employee registration ===============
			    System.out.println("Enter employee name::");
			    String name=sc.next();
			    System.out.println("Enter employee desg::");
			    String desg=sc.next();
			    System.out.println("Enter employee salary::");
			    float  salary=sc.nextFloat();
			    //create  Employee class obj having inputs
			    Employee  emp1=new Employee(name, desg, salary);
			     //invoke the b.method
			    try {
			    	String msg=controller.registerEmployeeDetails(emp1);
			    	System.out.println(msg);
			    }
			    catch(Exception e) {
			    	System.out.println("Internal Problem --try again::"+e.getMessage());
			    }
			
			  //===================gather inputs for fetching the employee details =============
			   // read inputs from enduser
			   System.out.println("enter desg1::");
			   String desg1=sc.next();
			   System.out.println("enter desg2::");
			   String desg2=sc.next();
			   System.out.println("enter desg3::");
			   String desg3=sc.next();
			 	//invoke the b.method
			try {
				List<Employee> list=controller.getEmployeesByDesgs(desg1,desg2, desg3);
				System.out.println("Employees having "+desg1+"...."+desg2+"...."+desg3);
				list.forEach(emp->{
					System.out.println(emp);
				});
			}
			catch(Exception e) {
				System.out.println("Internal problem -- Try Again ::"+e.getMessage());
				//e.printStackTrace();
			}
			  
			 
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("BootIocProj05LayeredAppMiniProjectRealtimeDIApplication.main() (end)");
		
	}//main

}//class
