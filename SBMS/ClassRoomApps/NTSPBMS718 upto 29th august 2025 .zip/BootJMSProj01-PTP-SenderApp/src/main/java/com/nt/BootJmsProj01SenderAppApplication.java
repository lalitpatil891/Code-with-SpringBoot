package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJmsProj01SenderAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJmsProj01SenderAppApplication.class, args);
	}

}
