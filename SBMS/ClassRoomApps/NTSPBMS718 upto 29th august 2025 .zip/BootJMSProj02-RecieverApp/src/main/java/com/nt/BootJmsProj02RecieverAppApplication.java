package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJmsProj02RecieverAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJmsProj02RecieverAppApplication.class, args);
	}

}
