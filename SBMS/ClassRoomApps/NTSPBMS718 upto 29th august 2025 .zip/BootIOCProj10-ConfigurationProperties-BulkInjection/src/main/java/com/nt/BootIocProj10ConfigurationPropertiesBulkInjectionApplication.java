package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.nt.sbeans.CourseCatalog;
import com.nt.sbeans.PersonalDetails;

@SpringBootApplication
public class BootIocProj10ConfigurationPropertiesBulkInjectionApplication {

	public static void main(String[] args) {
		  //create  IOC container
		try(ConfigurableApplicationContext ctx=SpringApplication.run(BootIocProj10ConfigurationPropertiesBulkInjectionApplication.class, args)){
			      //get Spring  Bean class obj ref
			    PersonalDetails details=ctx.getBean("pDetails",PersonalDetails.class);
			    System.out.println(details);
			   
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
	}//main

}//class
