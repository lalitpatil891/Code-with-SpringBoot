//PersonalDetails.java
package com.nt.sbeans;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("pDetails")
@ConfigurationProperties(prefix = "org.nit")
@Data
public class PersonalDetails {
	private  Integer pid;
	private  String pname;
	private  String  paddrs;
	private  String[] favColors;
	private  List<String> friends;
	private  Set<Long>  phones;
	private  Map<String,Object> idDetails;
	private  CourseCatalog  catalog;

}
