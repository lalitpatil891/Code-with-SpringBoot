//CourseCatalog.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Setter;
import lombok.ToString;

//@Component("cat")
//@Data
@ToString
@Setter
public class CourseCatalog {
	private double  cjFee;
	private  double  ajFee;
	private  double  oracleFee;
	private  double  spbmsFee;
	private  double  devopsFee;
	private  double   awsFee;
	private  double reactFee;
	
	
	
	
	

}
