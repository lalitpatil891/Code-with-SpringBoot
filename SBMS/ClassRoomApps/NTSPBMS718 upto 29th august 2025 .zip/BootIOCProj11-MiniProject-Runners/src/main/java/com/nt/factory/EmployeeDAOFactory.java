package com.nt.factory;

import javax.sql.DataSource;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nt.BootIocProj11LayeredAppMiniProjectRealtimeDIApplication;
import com.nt.dao.EmployeeMySQLDAOImpl;
import com.nt.dao.EmployeeOracleDAOImpl;
import com.nt.dao.IEmployeeDAO;


@Component("daoFactory")
public class EmployeeDAOFactory implements FactoryBean<IEmployeeDAO> {

   @Value("${dao.db}")
	private  String  db;
     @Autowired
    private   EmployeeOracleDAOImpl  oracleDAO;
     @Autowired
    private   EmployeeMySQLDAOImpl  mysqlDAO;
    
   

    
	@Override
	public IEmployeeDAO getObject() throws Exception {
		switch(db) {
		 case "oracle":
			   return  oracleDAO;
		 case "mysql":
			   return  mysqlDAO;
		  default:
			   throw  new IllegalArgumentException("Invalid dao");
		}
	
	}

	@Override
	public Class<?> getObjectType() {
		return IEmployeeDAO.class;
	}

}
