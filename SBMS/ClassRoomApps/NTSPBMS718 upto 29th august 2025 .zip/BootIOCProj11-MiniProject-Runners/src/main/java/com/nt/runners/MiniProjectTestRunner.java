//MiniProjectTestRunner.java
package com.nt.runners;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.controller.PayrollOperationsController;
import com.nt.model.Employee;
import com.nt.service.IEmployeeMgmtService;

@Component
public class MiniProjectTestRunner implements CommandLineRunner {
	@Autowired
	private  PayrollOperationsController  controller;

	@Override
	public void run(String... args) throws Exception {
		try(Scanner sc=new Scanner(System.in);){
			System.out.println("MiniProjectTestRunner.run() (ComandLine Runner())");
			  
			   //==================  gather inputs  for employee registration ===============
			    System.out.println("Enter employee name::");
			    String name=sc.next();
			    System.out.println("Enter employee desg::");
			    String desg=sc.next();
			    System.out.println("Enter employee salary::");
			    float  salary=sc.nextFloat();
			    //create  Employee class obj having inputs
			    Employee  emp1=new Employee(name, desg, salary);
			     //invoke the b.method
			    	String msg=controller.registerEmployeeDetails(emp1);
			    	System.out.println(msg);
			  
			  //===================gather inputs for fetching the employee details =============
			   // read inputs from enduser
			   System.out.println("enter desg1::");
			   String desg1=sc.next();
			   System.out.println("enter desg2::");
			   String desg2=sc.next();
			   System.out.println("enter desg3::");
			   String desg3=sc.next();
			 	//invoke the b.method
				List<Employee> list=controller.getEmployeesByDesgs(desg1,desg2, desg3);
				System.out.println("Employees having "+desg1+"...."+desg2+"...."+desg3);
				list.forEach(emp->{
					System.out.println(emp);
				});
			}//try
		   catch(Exception e) {
			   e.printStackTrace();
		   }
		
	}//main
}//class
