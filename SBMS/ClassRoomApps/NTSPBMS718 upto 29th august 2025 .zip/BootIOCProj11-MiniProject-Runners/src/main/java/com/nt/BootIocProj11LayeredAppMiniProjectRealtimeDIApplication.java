package com.nt;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.nt.controller.PayrollOperationsController;
import com.nt.model.Employee;


@SpringBootApplication
public class BootIocProj11LayeredAppMiniProjectRealtimeDIApplication {
	
  
	public static void main(String[] args) {
		System.out.println("BootIocProj05LayeredAppMiniProjectRealtimeDIApplication.main() (start)");
		//get IOC container
			SpringApplication.run(BootIocProj11LayeredAppMiniProjectRealtimeDIApplication.class, args);
			System.out.println("BootIocProj11LayeredAppMiniProjectRealtimeDIApplication.main()(end)");
	}//main

}//class
