package com.nt.sbeans;

public interface IEngine {
    public  void startEngine();
    public  void stopEngine();
    
}
