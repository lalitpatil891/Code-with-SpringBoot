package com.nt.runners;

import java.util.List;
import java.util.Set;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class ReportTest2Runner implements ApplicationRunner,Ordered {

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("ReportTest2Runner.run() (Application Runner)");
		
		//get  Non Option arg value
		List<String>  list=args.getNonOptionArgs();
		System.out.println("non -option arg values ::"+list);
		System.out.println("=======================");
		//get option arg values
		System.out.println("=======================");
		Set<String>  optNamesSet=args.getOptionNames();
		optNamesSet.forEach(name->{
			System.out.println(name+"...."+args.getOptionValues(name));
		});
		
		System.out.println("........................................................");
		}
	@Override
	public int getOrder() {
		return 100;
	}

}
