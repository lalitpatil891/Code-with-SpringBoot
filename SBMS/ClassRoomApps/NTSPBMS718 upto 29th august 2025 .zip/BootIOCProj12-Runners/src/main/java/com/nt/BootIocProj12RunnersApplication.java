package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootIocProj12RunnersApplication {

	public static void main(String[] args) {
		System.out.println("BootIocProj12RunnersApplication.main()(Start)");
		SpringApplication.run(BootIocProj12RunnersApplication.class, args);
		System.out.println("BootIocProj12RunnersApplication.main()(end)");
	}

}
