package com.nt.service;

public interface IShoppingService {
	
	public  String purchase(String items[],double prices[],String[] toMailIds)throws Exception;

}
