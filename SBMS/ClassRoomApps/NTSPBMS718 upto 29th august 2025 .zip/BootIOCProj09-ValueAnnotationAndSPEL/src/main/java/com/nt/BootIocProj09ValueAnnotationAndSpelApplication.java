package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;

import com.nt.sbeans.TrainingInistitute;

@SpringBootApplication
@PropertySource("com/nt/commons/myfile.properties")
public class BootIocProj09ValueAnnotationAndSpelApplication {

	public static void main(String[] args) {
		//get accees to IOC Container
		try(ConfigurableApplicationContext ctx=SpringApplication.run(BootIocProj09ValueAnnotationAndSpelApplication.class, args);){
			 //get  target spring bean class obj ref
			TrainingInistitute  inst=ctx.getBean("training",TrainingInistitute.class);
			System.out.println("Data is ::"+inst);
			System.out.println("Discounted  course fee::"+inst.calculateDiscountedFee());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
