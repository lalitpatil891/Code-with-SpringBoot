package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("training")
@Data
public class TrainingInistitute {
	// injecting the hardcoded values
	@Value("1001")
	private  Integer tid;
	
	// injecting the  values  collected from the properties file
	@Value("${inst.name}")
	private  String name;
	@Value("${inst.addrs}")
	private  String addrs;
	
	// injecting the System property values
	@Value("${os.name}")
	private  String osName;
	@Value("${user.name1}")
	private  String  userName;
	@Value("${inst.pincode}")
	private  long  pincode;
	// injecting the environment variable values
	@Value("${Path}")
	private  String  pathData;
	
	@Value("#{cat.corejavaFee + cat.advjavaFee + cat.oracleFee + cat.awsFee+ cat.spbmsFee+ cat.devopsFee+cat.reactjsFee}")
	private double javaPkgFee;
	@Value("#{cat.corejavaFee>5000}")
	private boolean isCJFeeHigh;
	public  double discount;
	
	//@Autowired
	@Value("#{cat}")
	private  CourseCatalog catalog;
	
	
	public double calculateDiscountedFee() {
		return  javaPkgFee-(javaPkgFee*0.3);
	}
	
	
	

}
