//CourseCatalog.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("cat")
@Data
public class CourseCatalog {
	@Value("${catalog.cjFee}")
	private double  corejavaFee;
	@Value("${catalog.ajFee}")
	private  double  advjavaFee;
	@Value("${catalog.oraFee}")
	private  double  oracleFee;
	@Value("${catalog.spbmsFee}")
	private  double  spbmsFee;
	@Value("${catalog.devopsFee}")
	private  double  devopsFee;
	@Value("${catalog.awsFee}")
	private  double   awsFee;
	@Value("${catalog.reactFee}")
	private  double reactjsFee;
	
	
	
	
	

}
