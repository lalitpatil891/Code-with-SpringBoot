package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootJmsProj01RecieverAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootJmsProj01RecieverAppApplication.class, args);
	}

}
