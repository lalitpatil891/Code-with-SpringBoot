package com.nt.comps;

public interface ICar {
    public  void makeCar();
    public   void  testDrive();
}
