//ICourier.java

package com.nt.comps;

public interface ICourier {
    public String  deliver(int oid);
}
